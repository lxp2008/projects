import random
import socket
import pickle
import threading
import sys
import os
import time
import uuid
import select
from tss08 import ThresholdECDSA

class CentralServer:
    def __init__(self, host='localhost', port=5000):
        self.host = host
        self.port = port
        self.nodes = {}
        self.node_count = 0
        self.a_values = []
        self.c = 0
        self.masked_values = {}
        self.all_nodes_registered = threading.Event()
        self.all_masked_values_received = threading.Event()
        self.threshold = 2
        self.total_nodes = 3
        self.shares = None
        self.public_key = None

    def start(self):
        """启动中央服务器"""
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.server_socket.bind((self.host, self.port))
        self.server_socket.listen(5)
        print(f"中央服务器启动，监听 {self.host}:{self.port}")
        
        try:
            while True:
                client_socket, address = self.server_socket.accept()
                client_thread = threading.Thread(target=self.handle_client, args=(client_socket, address))
                client_thread.daemon = True
                client_thread.start()
        except KeyboardInterrupt:
            print("服务器关闭")
        finally:
            self.server_socket.close()

    def handle_client(self, client_socket, address):
        node_id = None
        try:
            data = client_socket.recv(1024)
            message = pickle.loads(data)
            
            if message['type'] == 'register':
                node_id = message['node_id']
                self.nodes[node_id] = client_socket
                print(f"节点 {node_id} 已注册")
                
                if len(self.nodes) == self.node_count:
                    print("所有节点已注册，生成Beaver三元组和TSS设置")
                    self.generate_beaver_triplet()
                    self.generate_tss_setup()
                    self.all_nodes_registered.set()
                
                self.all_nodes_registered.wait()
                print(f"开始向节点 {node_id} 发送Beaver三元组")
                
                response = {
                    'type': 'beaver_triplet',
                    'a': self.a_values[node_id],
                    'c': self.c
                }
                client_socket.send(pickle.dumps(response))
                print(f"已向节点 {node_id} 发送Beaver三元组")
                
                tss_message = {
                    'type': 'tss_setup',
                    'share': self.shares[node_id + 1],  # 修复索引
                    'public_key': self.public_key.to_string()
                }
                client_socket.send(pickle.dumps(tss_message))
                print(f"已向节点 {node_id} 发送TSS设置")
                
                while True:
                    try:
                        data = client_socket.recv(1024)
                        if not data:
                            print(f"节点 {node_id} 断开连接")
                            break
                            
                        message = pickle.loads(data)
                        if message['type'] == 'masked_value':
                            self.masked_values[node_id] = message['value']
                            print(f"接收到节点 {node_id} 的masked value: {message['value']}")
                            
                            if len(self.masked_values) == self.node_count:
                                print("所有masked values已接收")
                                self.all_masked_values_received.set()
                                
                                result_message = {
                                    'type': 'masked_values',
                                    'masked_values': self.masked_values
                                }
                                for node_id_send, node_socket in list(self.nodes.items()):
                                    try:
                                        if node_socket.fileno() != -1:  # 检查套接字是否有效
                                            node_socket.send(pickle.dumps(result_message))
                                    except (ConnectionError, OSError) as e:
                                        print(f"向节点 {node_id_send} 发送数据失败: {e}")
                                        del self.nodes[node_id_send]
                                
                                total_sum = self.c + sum(self.masked_values.values())
                                print(f"安全加法的结果是: {total_sum}")
                                self.handle_partial_signatures()
                                
                                self.nodes.clear()
                                self.masked_values.clear()
                                self.a_values.clear()
                                self.c = 0
                                self.all_nodes_registered.clear()
                                self.all_masked_values_received.clear()
                                print("已重置服务器状态，准备接受新的计算请求")
                    except Exception as inner_e:
                        print(f"处理节点 {node_id} 消息时出错: {inner_e}")
                        break
        except Exception as e:
            print(f"处理客户端注册时发生错误: {e}")
            if node_id and node_id in self.nodes:
                del self.nodes[node_id]
        finally:
            if node_id and node_id in self.nodes:
                del self.nodes[node_id]
            client_socket.close()
            print(f"节点 {node_id} 连接已关闭")

    def generate_beaver_triplet(self):
        self.a_values = [random.randint(1, 10) for _ in range(self.node_count)]
        self.c = sum(self.a_values)
        print(f"生成的Beaver三元组: a_values={self.a_values}, c={self.c}")

    def set_node_count(self, count):
        self.node_count = count

    def generate_tss_setup(self):
        tss = ThresholdECDSA(self.threshold, self.total_nodes)
        self.shares = tss.generate_shares()
        self.public_key = tss.private_key.get_verifying_key()
        print(f"生成TSS设置，公钥: {self.public_key.to_string().hex()}")

    def handle_partial_signatures(self):
        partial_signatures = {}
        current_nodes = list(self.nodes.items())
        
        try:
            sign_request = {
                'type': 'sign_request',
                'message': 'Sign the computation result',
                'request_id': str(uuid.uuid4())
            }

            # 发送签名请求前清理失效节点
            valid_nodes = []
            for node_id, socket in current_nodes:
                try:
                    # 检查套接字是否有效
                    if socket.fileno() == -1:
                        print(f"节点 {node_id} 的套接字已关闭，跳过")
                        continue
                    socket.send(pickle.dumps(sign_request))
                    print(f"已向节点 {node_id} 发送签名请求")
                    valid_nodes.append((node_id, socket))
                except (OSError, ConnectionError) as e:
                    print(f"向节点 {node_id} 发送签名请求失败: {e}")
                    # 移除失效节点
                    if node_id in self.nodes:
                        del self.nodes[node_id]

            # 更新当前有效节点列表
            current_nodes = valid_nodes

            # 设置超时时间
            timeout = 10
            start_time = time.time()

            # 收集部分签名
            while len(partial_signatures) < self.threshold and (time.time() - start_time) < timeout:
                for node_id, socket in current_nodes.copy():
                    if node_id in partial_signatures:
                        continue
                    try:
                        # 检查套接字是否有效
                        if socket.fileno() == -1:
                            print(f"节点 {node_id} 的套接字已关闭，跳过")
                            current_nodes.remove((node_id, socket))
                            continue

                        ready, _, _ = select.select([socket], [], [], 0.1)
                        if ready:
                            data = socket.recv(4096)
                            if data:
                                message = pickle.loads(data)
                                if message.get('type') == 'partial_signature':
                                    partial_signatures[node_id] = message.get('signature')
                                    print(f"收到节点 {node_id} 的部分签名")
                    except (ConnectionResetError, ConnectionAbortedError, OSError) as e:
                        print(f"节点 {node_id} 连接异常: {e}")
                        current_nodes.remove((node_id, socket))
                        if node_id in self.nodes:
                            del self.nodes[node_id]
                    except Exception as e:
                        print(f"接收节点 {node_id} 签名时出错: {e}")

                time.sleep(0.1)

            # 广播签名结果（仅向有效节点）
            if len(partial_signatures) >= self.threshold:
                broadcast_message = {
                    'type': 'all_partial_signatures',
                    'signatures': partial_signatures,
                    'threshold': self.threshold,
                    'request_id': sign_request['request_id']
                }
                for node_id, socket in current_nodes:
                    try:
                        if socket.fileno() != -1:
                            socket.send(pickle.dumps(broadcast_message))
                    except Exception as e:
                        print(f"广播签名到节点 {node_id} 失败: {e}")

        except Exception as e:
            print(f"签名处理异常: {e}")
        finally:
            # 恢复套接字阻塞模式
            for _, socket in current_nodes:
                if socket.fileno() != -1:
                    socket.setblocking(True)

if __name__ == "__main__":
    server = CentralServer()
    server.set_node_count(3)
    server.start()