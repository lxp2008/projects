import socket
import pickle
import sys
from ecdsa import SigningKey, VerifyingKey, SECP256k1, util
import secrets
import hashlib
import binascii

class Node:
    def __init__(self, node_id, host='localhost', port=5000, threshold=2, total_nodes=3):
        self.node_id = node_id
        self.host = host
        self.port = port
        self.threshold = threshold
        self.total_nodes = total_nodes
        self.curve = SECP256k1
        self.G = self.curve.generator
        self.order = self.curve.order
        self.a = None
        self.c = None
        self.x = None
        self.masked_value = None
        self.result = None
        self.all_masked_values = {}
        self.private_key_share = None
        self.public_key = None
        self.participant_ids = []
        self.final_signature = None  # 用于保存最终签名

    def connect_to_server(self):
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            self.socket.connect((self.host, self.port))
            print(f"节点 {self.node_id} 已连接到服务器")
            return True
        except Exception as e:
            print(f"连接服务器失败: {e}")
            return False

    def register(self):
        message = {
            'type': 'register',
            'node_id': self.node_id
        }
        self.socket.send(pickle.dumps(message))
        print(f"节点 {self.node_id} 已发送注册请求")

    def receive_beaver_triplet(self):
        data = self.socket.recv(1024)
        message = pickle.loads(data)
        if message['type'] == 'beaver_triplet':
            self.a = message['a']
            self.c = message['c']
            print(f"节点 {self.node_id} 收到Beaver三元组: a={self.a}, c={self.c}")

        data = self.socket.recv(1024)
        message = pickle.loads(data)
        if message['type'] == 'tss_setup':
            self.private_key_share = message['share']
            self.public_key = VerifyingKey.from_string(message['public_key'], curve=self.curve)
            print(f"节点 {self.node_id} 收到TSS设置")

    def handle_message(self, message):
        if message['type'] == 'masked_values':
            self.all_masked_values = message['masked_values']
            print(f"节点 {self.node_id} 收到所有masked values: {self.all_masked_values}")
            self.result = self.c + sum(self.all_masked_values.values())
            print(f"节点 {self.node_id} 计算的安全加法结果: {self.result}")
        
        elif message['type'] == 'sign_request':
            try:
                message_to_sign = message['message'].encode()
                k = self.result % self.order if self.result else 123456789
                r = (k * self.G).x() % self.order
                e = self._hash_message(message_to_sign)
                k_inv = pow(k, -1, self.order)
                s_i = (e + r * self.private_key_share) * k_inv % self.order
                partial_sig = (r, s_i, self.node_id)
                response = {
                    'type': 'partial_signature',
                    'signature': partial_sig,
                    'request_id': message.get('request_id')
                }
                self.socket.send(pickle.dumps(response))
                print(f"节点 {self.node_id} 已发送部分签名")
            except Exception as e:
                print(f"生成部分签名时出错: {e}")

        elif message['type'] == 'all_partial_signatures':
            try:
                signatures = message['signatures']
                if len(signatures) < self.threshold:
                    print(f"签名不足 ({len(signatures)}/{self.threshold})")
                    return
                r_values = {sig[0] for sig in signatures.values()}
                if len(r_values) != 1:
                    print("r值不一致")
                    return
                r = r_values.pop()
                s_values = [sig[1] for sig in signatures.values()]
                final_s = sum(s_values) % self.order
                final_signature = (r, final_s)
                self.final_signature = final_signature  # 保存最终签名
                print(f"节点 {self.node_id} 聚合签名成功: {final_signature}")
            except Exception as e:
                print(f"处理签名时出错: {e}")

    def set_input(self, x):
        self.x = x
        print(f"节点 {self.node_id} 设置输入值: {x}")

    def mask_input(self):
        self.masked_value = self.x - self.a
        print(f"节点 {self.node_id} 计算masked value: {self.masked_value}")

    def send_masked_value(self):
        message = {
            'type': 'masked_value',
            'value': self.masked_value
        }
        self.socket.send(pickle.dumps(message))
        print(f"节点 {self.node_id} 发送masked value: {self.masked_value}")

    def close(self):
        """关闭连接"""
        if hasattr(self, 'socket'):
            self.socket.close()
            print(f"节点 {self.node_id} 已关闭连接")

    def _hash_message(self, message):
        h = hashlib.sha256(message).digest()
        return int.from_bytes(h, byteorder='big') % self.order

def run_node(node_id, input_value):
    node = Node(node_id)
    if node.connect_to_server():
        node.register()
        node.receive_beaver_triplet()
        node.set_input(input_value)
        node.mask_input()
        node.send_masked_value()
        try:
            # 持续监听服务器消息，直到收到最终签名
            while True:
                data = node.socket.recv(4096)
                if not data:
                    print(f"节点 {node_id} 与服务器连接断开")
                    break
                message = pickle.loads(data)
                node.handle_message(message)
                # 检查是否完成签名聚合
                if hasattr(node, 'final_signature'):
                    print(f"节点 {node_id} 完成所有流程")
                    break
        except Exception as e:
            print(f"处理消息时出错: {e}")
        finally:
            node.close()

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("使用方法: python node.py <node_id> <input_value>")
        sys.exit(1)
    node_id = int(sys.argv[1])
    input_value = int(sys.argv[2])
    run_node(node_id, input_value)