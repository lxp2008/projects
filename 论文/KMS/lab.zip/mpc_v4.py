from __future__ import annotations
import hashlib
from typing import List, Tuple
from ecdsa import SECP256k1, VerifyingKey, ellipticcurve, numbertheory
from ecdsa.ellipticcurve import PointJacobi
from phe import paillier
import random

def lagrange_interpolate(shares: List[Tuple[int, int]], prime: int) -> int:
    s = 0
    for i, yi in shares:
        numerator = 1
        denominator = 1
        for j, _ in shares:
            if i != j:
                numerator = (numerator * (0 - j)) % prime
                denominator = (denominator * (i - j)) % prime
        lagrange_coeff = (numerator * numbertheory.inverse_mod(denominator, prime)) % prime
        s = (s + yi * lagrange_coeff) % prime
    return s

class DKG:
    def __init__(self, t: int, n: int):
        self.t = t
        self.n = n
    
    def generate_shared_secret(self) -> List[Tuple[int, int]]:
        all_shares = []
        for _ in range(self.n):
            secret = random.randint(1, SECP256k1.order)
            coeffs = [secret] + [random.randint(0, SECP256k1.order) for _ in range(self.t-1)]
            shares = []
            for i in range(1, self.n+1):
                share = sum(coeff * pow(i, j, SECP256k1.order) for j, coeff in enumerate(coeffs)) % SECP256k1.order
                shares.append((i, share))
            all_shares.append(shares)
        d_shares = []
        for i in range(self.n):
            d_i = sum(shares[i][1] for shares in all_shares) % SECP256k1.order
            d_shares.append((i+1, d_i))
        return d_shares

class ThresholdECDSA:
    def __init__(self, t: int, n: int):
        self.t = t
        self.n = n
        self.dkg = DKG(t, n)
        self.paillier_pubkey, self.paillier_privkey = paillier.generate_paillier_keypair()
    
    def keygen(self) -> Tuple[List[Tuple[int, int]], VerifyingKey]:
        d_shares = self.dkg.generate_shared_secret()
        zero_point = PointJacobi(SECP256k1.curve, 0, 0, 1, SECP256k1.order)
        pubkey_point = sum(
            (d_i * SECP256k1.generator for _, d_i in d_shares),
            start=zero_point
        )
        pubkey = VerifyingKey.from_public_point(pubkey_point, curve=SECP256k1)
        d = lagrange_interpolate(d_shares[:self.t], SECP256k1.order)
        print(f"[DEBUG] Recovered private key d: {hex(d)}")
        print(f"[DEBUG] Public key: {pubkey.to_string('compressed').hex()}")
        return d_shares, pubkey
    
    def precompute(self, d_shares: List[Tuple[int, int]], num_precomputed: int = 10):
        k_pool = []
        for _ in range(num_precomputed):
            k_shares = self.dkg.generate_shared_secret()
            encrypted_shares = [self.paillier_pubkey.encrypt(share[1]) for share in k_shares]
            zero_point = PointJacobi(SECP256k1.curve, 0, 0, 1, SECP256k1.order)
            R = sum(
                (k_i * SECP256k1.generator for _, k_i in k_shares),
                start=zero_point
            )
            k_pool.append({'shares': k_shares, 'encrypted': encrypted_shares, 'R': R})
        return k_pool
    
    def sign(self, d_shares: List[Tuple[int, int]], k_pool: List[dict], msg: bytes) -> Tuple[int, int]:
        h = int.from_bytes(hashlib.sha256(msg).digest(), 'big')
        selected_k = h % len(k_pool)
        k_data = k_pool[selected_k]
        R = k_data['R'].x()
        r = R % SECP256k1.order
        
        # 解密并验证k分片
        k_shares = []
        for share, enc in zip(k_data['shares'], k_data['encrypted']):
            decrypted = self.paillier_privkey.decrypt(enc)
            assert decrypted == share[1], "Paillier解密分片错误"
            k_shares.append((share[0], decrypted))
        
        k = lagrange_interpolate(k_shares[:self.t], SECP256k1.order)
        k_inv = pow(k, -1, SECP256k1.order)
        d = lagrange_interpolate(d_shares[:self.t], SECP256k1.order)
        s = (k_inv * (h + r * d)) % SECP256k1.order
        
        print(f"[DEBUG] Hash h: {hex(h)}")
        print(f"[DEBUG] Recovered k: {hex(k)}")
        print(f"[DEBUG] Calculated s: {hex(s)}")
        return (r, s)
    
    @staticmethod
    def verify_sig(pubkey: VerifyingKey, msg: bytes, sig: Tuple[int, int]) -> bool:
        try:
            sig_bytes = sig[0].to_bytes(32, 'big') + sig[1].to_bytes(32, 'big')
            pubkey.verify_digest(
                sig_bytes,
                digest=hashlib.sha256(msg).digest(),
                sigdecode=lambda sig_bytes, order: (
                    int.from_bytes(sig_bytes[:32], 'big'),
                    int.from_bytes(sig_bytes[32:], 'big')
                )
            )
            return True
        except Exception as e:
            print(f"Verification failed: {e}")
            return False

if __name__ == "__main__":
    t = 3
    n = 5
    msg = b"Hello, Threshold ECDSA!"
    
    threshold_ecdsa = ThresholdECDSA(t, n)
    d_shares, pubkey = threshold_ecdsa.keygen()
    k_pool = threshold_ecdsa.precompute(d_shares, num_precomputed=10)
    r, s = threshold_ecdsa.sign(d_shares, k_pool, msg)
    print(f"Signature (r, s): {hex(r)}, {hex(s)}")
    is_valid = threshold_ecdsa.verify_sig(pubkey, msg, (r, s))
    print(f"Valid: {is_valid}")