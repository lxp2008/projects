import random
from ecdsa import SigningKey, SECP256k1
from collections import deque
import time

# =====================================
# 模块1: BGV加密框架（简化版）
# =====================================
class BGV:
    def __init__(self, poly_degree=1024, moduli_chain=[2**32-1, 2**16-1]):
        self.poly_degree = poly_degree
        self.moduli_chain = moduli_chain
        self.current_modulus = moduli_chain[0]  # 定义 current_modulus
    
    def encrypt(self, plaintext):
        return {"ct": plaintext, "modulus": self.current_modulus}
    
    def decrypt(self, ciphertext):
        return ciphertext["ct"] % ciphertext["modulus"]
    
    def add(self, ct1, ct2):
        assert ct1["modulus"] == ct2["modulus"]
        return {"ct": (ct1["ct"] + ct2["ct"]) % ct1["modulus"], "modulus": ct1["modulus"]}
    
    def multiply(self, ct1, ct2, triple):
        e = (ct1["ct"] - triple["a"]["ct"]) % ct1["modulus"]  # 修正三元组访问
        f = (ct2["ct"] - triple["b"]["ct"]) % ct2["modulus"]
        return self.add(
            self.add(
                triple["c"],
                self.add(
                    self.encrypt(e * triple["b"]["ct"]),
                    self.encrypt(f * triple["a"]["ct"])
                )
            ),
            self.encrypt(e * f)
        )

# =====================================
# 模块2: 滑动窗口任务调度
# =====================================
class SlidingWindowScheduler:
    def __init__(self, window_size=5):
        self.window_size = window_size
        self.tasks = deque()
    
    def add_task(self, task):
        self.tasks.append((time.time(), task))
    
    def slide(self):
        current_time = time.time()
        while self.tasks and current_time - self.tasks[0][0] > self.window_size:
            self.tasks.popleft()
    
    def get_current_load(self):
        return len(self.tasks)

# =====================================
# 模块3: MPC-ECDSA协议实现（修复属性错误）
# =====================================
class MPC_ECDSA:
    def __init__(self, n_parties=3):
        self.bgv = BGV()
        self.window_scheduler = SlidingWindowScheduler()
        self.triples = []
        
        self.curve = SECP256k1
        self.G = self.curve.generator
        self.order = self.curve.order
    
    def precompute_triples(self, n):
        """离线预计算生成乘法三元组"""
        for _ in range(n):
            # 通过 self.bgv 访问 current_modulus
            a = random.randint(1, self.bgv.current_modulus - 1)
            b = random.randint(1, self.bgv.current_modulus - 1)
            c = a * b % self.bgv.current_modulus
            self.triples.append({
                "a": self.bgv.encrypt(a),
                "b": self.bgv.encrypt(b),
                "c": self.bgv.encrypt(c)
            })
    
    def generate_K(self):
        """多方协作生成临时密钥K"""
        k_shares = [self.bgv.encrypt(random.randint(1, self.order - 1)) 
                    for _ in range(3)]
        
        k_encrypted = k_shares[0]
        for share in k_shares[1:]:
            k_encrypted = self.bgv.add(k_encrypted, share)
        
        triple = self.triples.pop()
        verified = self.bgv.multiply(k_encrypted, triple["a"], triple)
        return self.bgv.decrypt(verified)
    
    def compute_R(self, k):
        """计算椭圆曲线点R = k*G"""
        return k * self.G
    
    def sign(self, msg):
        """完整的MPC-ECDSA签名流程"""
        k = self.generate_K()
        R = self.compute_R(k)
        r = R.x() % self.order
        print(f"k 的值: {k}")
        print(f"r 的值: {r}")
        sk = SigningKey.generate()
        vk = sk.get_verifying_key()
        signature = sk.sign(msg, k=k)
        return signature, vk

# =====================================
# 测试代码
# =====================================
if __name__ == "__main__":
    mpc = MPC_ECDSA(n_parties=3)
    print("预计算乘法三元组...")
    mpc.precompute_triples(10)
    
    message = b"Hello, MPC-ECDSA!"
    print("\n生成签名...")
    signature, vk = mpc.sign(message)
    message1 = b"Hello, MPC-ECDSA!"
    print("验证结果:", vk.verify(signature, message1))