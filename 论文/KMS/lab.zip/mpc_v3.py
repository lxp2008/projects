import hashlib
from typing import List, Tuple
from ecdsa import SigningKey, SECP256k1, VerifyingKey, ellipticcurve, numbertheory
from ecdsa.util import sigencode_der, sigdecode_der
from phe import paillier
import random

def lagrange_interpolate(x: int, shares: List[Tuple[int, int]], prime: int) -> int:
    """拉格朗日插值法恢复秘密值"""
    s = 0
    for i, yi in shares:
        numerator = 1
        denominator = 1
        for j, yj in shares:
            if i != j:
                numerator = (numerator * (x - j)) % prime
                denominator = (denominator * (i - j)) % prime
        lagrange_coeff = (numerator * numbertheory.inverse_mod(denominator, prime)) % prime
        s = (s + yi * lagrange_coeff) % prime
    return s

class FeldmanVSS:
    """Feldman可验证秘密共享（支持拉格朗日插值）"""
    def __init__(self, t: int, n: int):
        self.t = t
        self.n = n
        
    def generate_shares(self, secret: int) -> Tuple[List[Tuple[int, int]], List[ellipticcurve.PointJacobi]]:
        """生成分片和承诺：分片格式为 [(x_i, f(x_i))]"""
        coeffs = [secret] + [random.randint(0, SECP256k1.order) for _ in range(self.t-1)]
        shares = []
        # 承诺为多项式系数对应的椭圆曲线点
        commitments = [coeff * SECP256k1.generator for coeff in coeffs]
        for i in range(1, self.n+1):
            share = sum(coeff * pow(i, j, SECP256k1.order) for j, coeff in enumerate(coeffs)) % SECP256k1.order
            shares.append((i, share))
        return shares, commitments

class Participant:
    """参与方节点（包含分片和承诺）"""
    def __init__(self, sk_share: Tuple[int, int], pk_commitments: List[ellipticcurve.PointJacobi]):
        self.sk_share = sk_share  # (x_i, f(x_i))
        self.pk_commitments = pk_commitments

class ThresholdECDSA:
    def __init__(self, t: int, n: int):
        self.t = t
        self.n = n
        self.vss = FeldmanVSS(t, n)
        self.paillier_pubkey, self.paillier_privkey = paillier.generate_paillier_keypair()
        self.k_pool = []
    
    def keygen_phase(self) -> Tuple[List[Participant], VerifyingKey]:
        """密钥生成阶段"""
        secret = random.randint(1, SECP256k1.order)
        sk_shares, commitments = self.vss.generate_shares(secret)
        participants = [Participant(share, commitments) for share in sk_shares]
        # 生成全局公钥
        pubkey_point = secret * SECP256k1.generator
        pubkey = VerifyingKey.from_public_point(pubkey_point, curve=SECP256k1)
        return participants, pubkey
    
    def precompute_phase(self, participants: List[Participant], num_precomputed: int = 10):
        """预计算随机数k的分片"""
        for _ in range(num_precomputed):
            k = random.randint(1, SECP256k1.order)
            k_shares, _ = self.vss.generate_shares(k)
            encrypted_shares = [self.paillier_pubkey.encrypt(share[1]) for share in k_shares]  # 加密f(x_i)
            R = k * SECP256k1.generator
            self.k_pool.append({
                'shares': k_shares,    # 格式 [(x_i, f(x_i))]
                'encrypted': encrypted_shares,
                'R': R
            })
    
    def signing_phase(self, participants: List[Participant], msg: bytes) -> Tuple[int, int]:
        """签名阶段（使用拉格朗日插值恢复k和d）"""
        msg_hash = int.from_bytes(hashlib.sha256(msg).digest(), 'big')
        selected_k = msg_hash % len(self.k_pool)
        k_data = self.k_pool[selected_k]
        R = k_data['R'].x()
        r = R % SECP256k1.order
        
        # 解密k分片并恢复k
        k_shares = [(share[0], self.paillier_privkey.decrypt(enc)) for share, enc in zip(k_data['shares'], k_data['encrypted'])]
        k = lagrange_interpolate(0, k_shares[:self.t], SECP256k1.order)
        k_inv = pow(k, -1, SECP256k1.order)
        
        # 恢复私钥d（通过分片插值）
        d_shares = [participant.sk_share for participant in participants[:self.t]]
        d = lagrange_interpolate(0, d_shares, SECP256k1.order)
        
        # 计算s = k^{-1} (h + r*d) mod n
        s = (k_inv * (msg_hash + r * d)) % SECP256k1.order
        return (R, s)
    
    @staticmethod
    def verify_sig(pubkey: VerifyingKey, msg: bytes, sig: Tuple[int, int]) -> bool:
        """验证签名"""
        try:
            der_sig = sigencode_der(sig[0], sig[1], SECP256k1.order)
            pubkey.verify(der_sig, msg, hashfunc=hashlib.sha256, sigdecode=sigdecode_der)
            return True
        except Exception as e:
            print(f"Verification failed: {e}")
            return False

if __name__ == "__main__":
    t = 3
    n = 5
    msg = b"Hello, Threshold ECDSA11!"
    
    threshold_ecdsa = ThresholdECDSA(t, n)
    participants, pubkey = threshold_ecdsa.keygen_phase()
    print(f"Public Key (compressed): {pubkey.to_string('compressed').hex()}")
    
    threshold_ecdsa.precompute_phase(participants, num_precomputed=10)
    r, s = threshold_ecdsa.signing_phase(participants, msg)
    print(f"Signature (r, s): {hex(r)}, {hex(s)}")
    
    is_valid = threshold_ecdsa.verify_sig(pubkey, msg, (r, s))
    print(f"Valid: {is_valid}")