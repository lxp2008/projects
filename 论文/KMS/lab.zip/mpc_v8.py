import hashlib
from math import gcd
from typing import List, Tuple
from ecdsa import SECP256k1, VerifyingKey, ellipticcurve, numbertheory
from ecdsa.ellipticcurve import PointJacobi
from phe import paillier
import random

# 辅助函数：拉格朗日系数计算
def lagrange_coeff(i: int, participants: List[int], prime: int) -> int:
    numerator = 1
    denominator = 1
    for j in participants:
        if i != j:
            numerator = (numerator * (0 - j)) % prime
            denominator = (denominator * (i - j)) % prime
    return (numerator * numbertheory.inverse_mod(denominator, prime)) % prime

def lcm(a: int, b: int) -> int:
    return a * b // gcd(a, b)

# Schnorr证明系统（保持不变）
# Feldman VSS（保持不变）

# 修复版门限Paillier加密
class ThresholdPaillier:
    def __init__(self, t: int, n: int):
        self.t = t
        self.n = n
        self.pubkey = None
        self.mu = None
        self.priv_shares = []
    
    def keygen(self):
        pub, priv = paillier.generate_paillier_keypair()
        self.pubkey = pub
        p, q = priv.p, priv.q
        n = pub.n
        lambda_val = lcm(p-1, q-1)
        g = n + 1
        
        h = pow(g, lambda_val, n**2)
        L_h = (h - 1) // n
        mu = pow(L_h, -1, n)
        self.mu = mu
        
        prime = n
        coefficients = [lambda_val] + [random.randint(0, prime) for _ in range(self.t-1)]
        self.priv_shares = [(i, sum(c * pow(i, j, prime) for j, c in enumerate(coefficients)) % prime)
                           for i in range(1, self.n+1)]
    
    def encrypt(self, plaintext: int):
        return self.pubkey.encrypt(plaintext)
    
    def partial_decrypt(self, ciphertext, share_index: int):
        share = next(s[1] for s in self.priv_shares if s[0] == share_index)
        return pow(ciphertext.ciphertext(), share, self.pubkey.n**2)
    
    def combine(self, ciphertext, partials: List[Tuple[int, int]]):
        n = self.pubkey.n
        prime = n
        result = 1
        
        for idx, val in partials:
            numerator = 1
            denominator = 1
            for other_idx, _ in partials:
                if idx != other_idx:
                    numerator = (numerator * -other_idx) % prime
                    denominator = (denominator * (idx - other_idx)) % prime
            lambda_i = (numerator * pow(denominator, -1, prime)) % prime
            result = (result * pow(val, lambda_i, n**2)) % n**2
        
        L = lambda x: (x - 1) // n
        return (L(result) * self.mu) % n

# 修复版阈值ECDSA
class ThresholdECDSA:
    def __init__(self, t: int, n: int):
        self.t = t
        self.n = n
        self.vss = FeldmanVSS(t, n)
        self.paillier = ThresholdPaillier(t, n)
        self.paillier.keygen()
    
    def keygen_phase(self) -> Tuple[List[Tuple[int, int]], VerifyingKey]:
        secret = random.randint(1, SECP256k1.order)
        sk_shares, _ = self.vss.generate_shares(secret)
        pubkey = secret * SECP256k1.generator
        return sk_shares, VerifyingKey.from_public_point(pubkey, curve=SECP256k1)
    
    def precompute_phase(self, num_precomputed: int = 10) -> List[dict]:
        k_pool = []
        for _ in range(num_precomputed):
            k = random.randint(1, SECP256k1.order)
            k_shares, _ = self.vss.generate_shares(k)
            encrypted = [self.paillier.encrypt(s[1]) for s in k_shares]
            k_pool.append({
                'shares': k_shares,
                'encrypted': encrypted,
                'R': k * SECP256k1.generator
            })
        return k_pool
    
    def signing_phase(self, sk_shares: List[Tuple[int, int]], k_pool: List[dict], msg: bytes) -> Tuple[int, int]:
        h = int.from_bytes(hashlib.sha256(msg).digest(), 'big')
        k_data = k_pool[h % len(k_pool)]
        R = k_data['R'].x()
        r = R % SECP256k1.order
        
        # 关键修复点：分离k分片和私钥分片的参与者
        k_shares = k_data['shares'][:self.t]
        k_participants = [s[0] for s in k_shares]
        d_participants = [s[0] for s in sk_shares[:self.t]]
        
        # 门限解密k分片
        decrypted_k = []
        for enc in k_data['encrypted'][:self.t]:
            partials = [(i, self.paillier.partial_decrypt(enc, i)) 
                       for i in k_participants]
            decrypted_k.append(self.paillier.combine(enc, partials))
        
        # 重构k值
        k = sum(d * lagrange_coeff(k_participants[i], k_participants, SECP256k1.order) 
            for i, d in enumerate(decrypted_k)) % SECP256k1.order
        
        # 计算签名s
        k_inv = pow(k, -1, SECP256k1.order)
        s = sum(lagrange_coeff(d_participants[i], d_participants, SECP256k1.order) * 
               (h + r * d) % SECP256k1.order 
            for i, (_, d) in enumerate(sk_shares[:self.t])) * k_inv % SECP256k1.order
        
        # 调试输出
        print(f"[Debug] h:{h} r:{r} k:{k} k_inv:{k_inv} s:{s}")
        return (r, s)
    
    @staticmethod
    def verify_sig(pubkey: VerifyingKey, msg: bytes, sig: Tuple[int, int]) -> bool:
        try:
            r, s = sig
            sig_bytes = r.to_bytes(32, 'big') + s.to_bytes(32, 'big')
            return pubkey.verify_digest(
                sig_bytes,
                digest=hashlib.sha256(msg).digest(),
                sigdecode=lambda bs, _: (int.from_bytes(bs[:32], 'big'), 
                                         int.from_bytes(bs[32:], 'big')))
        except Exception as e:
            print(f"Verification failed: {str(e)}")
            return False

if __name__ == "__main__":
    # 测试参数
    t, n = 2, 3
    msg = b"Hello, Threshold ECDSA!"
    
    # 初始化
    scheme = ThresholdECDSA(t, n)
    
    # 密钥生成
    sk_shares, pubkey = scheme.keygen_phase()
    print(f"Public key: {pubkey.to_string().hex()}")
    
    # 预计算
    k_pool = scheme.precompute_phase()
    
    # 签名
    r, s = scheme.signing_phase(sk_shares, k_pool, msg)
    print(f"Signature: r={r}\ns={s}")
    
    # 验证
    print("Verification result:", 
          "Success" if scheme.verify_sig(pubkey, msg, (r, s)) else "Failed")