import hashlib
from typing import List, Tuple
from ecdsa import SECP256k1, VerifyingKey, ellipticcurve, numbertheory
from ecdsa.ellipticcurve import PointJacobi
from phe import paillier
import random

# ========== 基础工具 ==========
def lagrange_coeff(i: int, participants: List[int], prime: int) -> int:
    """计算拉格朗日系数 λ_i (用于分片插值)"""
    numerator = 1
    denominator = 1
    for j in participants:
        if i != j:
            numerator = (numerator * (0 - j)) % prime
            denominator = (denominator * (i - j)) % prime
    return (numerator * numbertheory.inverse_mod(denominator, prime)) % prime

# ========== 基础工具 ==========
def lagrange_coeff(i: int, participants: List[int], prime: int) -> int:
    """计算拉格朗日插值系数 λ_i"""
    numerator = 1
    denominator = 1
    for j in participants:
        if i != j:
            numerator = (numerator * (0 - j)) % prime
            denominator = (denominator * (i - j)) % prime
    return (numerator * numbertheory.inverse_mod(denominator, prime)) % prime

# ========== 分布式密钥生成（DKG） ==========
class FeldmanVSS:
    """Feldman可验证秘密共享协议"""
    def __init__(self, t: int, n: int):
        self.t = t  # 门限值
        self.n = n  # 总分片数
    
    def generate_shares(self, secret: int) -> Tuple[List[Tuple[int, int]], List[PointJacobi]]:
        """生成私钥分片和承诺"""
        coeffs = [secret] + [random.randint(0, SECP256k1.order) for _ in range(self.t-1)]
        shares = []
        commitments = [coeff * SECP256k1.generator for coeff in coeffs]
        for i in range(1, self.n+1):
            share = sum(coeff * pow(i, j, SECP256k1.order) for j, coeff in enumerate(coeffs)) % SECP256k1.order
            shares.append((i, share))
        return shares, commitments

# ========== 门限ECDSA协议 ==========
class ThresholdECDSA:
    def __init__(self, t: int, n: int):
        self.t = t
        self.n = n
        self.vss = FeldmanVSS(t, n)
        self.paillier_pubkey, self.paillier_privkey = paillier.generate_paillier_keypair()
    
    def keygen_phase(self) -> Tuple[List[Tuple[int, int]], VerifyingKey]:
        """分布式密钥生成"""
        secret = random.randint(1, SECP256k1.order)
        sk_shares, commitments = self.vss.generate_shares(secret)
        pubkey_point = secret * SECP256k1.generator
        pubkey = VerifyingKey.from_public_point(pubkey_point, curve=SECP256k1)
        return sk_shares, pubkey
    
    def precompute_phase(self, participants: List[Tuple[int, int]], num_precomputed: int = 10) -> List[dict]:
        """预计算随机数k的分片（Paillier加密）"""
        k_pool = []
        for _ in range(num_precomputed):
            k = random.randint(1, SECP256k1.order)
            k_shares, _ = self.vss.generate_shares(k)
            encrypted_shares = [self.paillier_pubkey.encrypt(share[1]) for share in k_shares]
            R = k * SECP256k1.generator
            k_pool.append({
                'shares': k_shares,          # 分片格式 [(x_i, k_i)]
                'encrypted': encrypted_shares,
                'R': R
            })
        return k_pool
    
    def signing_phase(self, sk_shares: List[Tuple[int, int]], k_pool: List[dict], msg: bytes) -> Tuple[int, int]:
        """门限签名（分布式计算 k^{-1}）"""
        h = int.from_bytes(hashlib.sha256(msg).digest(), 'big')
        selected_k = h % len(k_pool)
        k_data = k_pool[selected_k]
        R = k_data['R'].x()
        r = R % SECP256k1.order
        participants = [share[0] for share in sk_shares[:self.t]]

        # ==== 关键改进：分布式计算 k^{-1} ====
        # 1. 生成随机数 gamma 的分片（模拟安全乘法协议）
        gamma_shares, _ = self.vss.generate_shares(random.randint(1, SECP256k1.order))
        
        # 2. 协作计算 Gamma = k * gamma（使用预计算的Beaver三元组简化实现）
        # 实际协议中需使用安全乘法，此处简化为中心化计算
        k = sum(share[1] * lagrange_coeff(share[0], participants, SECP256k1.order) 
               for share in k_data['shares'][:self.t]) % SECP256k1.order
        gamma = sum(share[1] * lagrange_coeff(share[0], participants, SECP256k1.order) 
                   for share in gamma_shares[:self.t]) % SECP256k1.order
        Gamma = (k * gamma) % SECP256k1.order
        Gamma_inv = pow(Gamma, -1, SECP256k1.order)
        
        # 3. 计算 k^{-1} 分片：k^{-1}_i = gamma_i * Gamma^{-1} mod n
        k_inv_shares = [
            (gamma_share[0], (gamma_share[1] * Gamma_inv) % SECP256k1.order)
            for gamma_share in gamma_shares[:self.t]
        ]
        
        # 4. 聚合 k^{-1} = ∑λ_i * k^{-1}_i
        k_inv = sum(
            share[1] * lagrange_coeff(share[0], participants, SECP256k1.order)
            for share in k_inv_shares
        ) % SECP256k1.order

        # ==== 计算签名 s ====
        s = 0
        for (i, d_i) in sk_shares[:self.t]:
            lambda_i = lagrange_coeff(i, participants, SECP256k1.order)
            term1 = (lambda_i * h * k_inv) % SECP256k1.order
            term2 = (lambda_i * r * d_i * k_inv) % SECP256k1.order
            s = (s + term1 + term2) % SECP256k1.order
        
        return (r, s)
    
    @staticmethod
    def verify_sig(pubkey: VerifyingKey, msg: bytes, sig: Tuple[int, int]) -> bool:
        """验证签名（标准ECDSA）"""
        try:
            sig_bytes = sig[0].to_bytes(32, 'big') + sig[1].to_bytes(32, 'big')
            pubkey.verify_digest(
                sig_bytes,
                digest=hashlib.sha256(msg).digest(),
                sigdecode=lambda sig_bytes, order: (
                    int.from_bytes(sig_bytes[:32], 'big'),
                    int.from_bytes(sig_bytes[32:], 'big')
                )
            )
            return True
        except Exception as e:
            print(f"Verification failed: {e}")
            return False

# ========== 测试用例 ==========
if __name__ == "__main__":
    t = 3  # 门限值
    n = 5  # 总分片数
    msg = b"Hello, Threshold ECDSA!"
    
    # 初始化协议
    threshold_ecdsa = ThresholdECDSA(t, n)
    
    # 密钥生成
    sk_shares, pubkey = threshold_ecdsa.keygen_phase()
    print(f"Public Key (compressed): {pubkey.to_string('compressed').hex()}")
    
    # 预计算随机数k分片
    k_pool = threshold_ecdsa.precompute_phase(sk_shares, num_precomputed=10)
    
    # 生成签名
    r, s = threshold_ecdsa.signing_phase(sk_shares, k_pool, msg)
    print(f"Signature (r, s): {hex(r)}, {hex(s)}")
    
    # 验证签名
    is_valid = threshold_ecdsa.verify_sig(pubkey, msg, (r, s))
    print(f"Valid: {is_valid}")