import hashlib
from typing import List, Tuple
from ecdsa import SigningKey, SECP256k1, VerifyingKey, ellipticcurve
from ecdsa.util import sigencode_der, sigdecode_der
from phe import paillier
import random

class FeldmanVSS:
    """Feldman可验证秘密共享简化实现"""
    def __init__(self, t: int, n: int):
        self.t = t  # 门限
        self.n = n  # 总参与方数
        
    def generate_shares(self, secret: int) -> Tuple[List[int], List[ellipticcurve.PointJacobi]]:
        coeffs = [secret] + [random.randint(0, SECP256k1.order) for _ in range(self.t-1)]
        shares = []
        commitments = []
        for i in range(1, self.n+1):
            share = sum(coeff * pow(i, j, SECP256k1.order) for j, coeff in enumerate(coeffs)) % SECP256k1.order
            shares.append(share)
            commitment = SECP256k1.generator
            for j, coeff in enumerate(coeffs):
                commitment += (coeff * pow(i, j, SECP256k1.order)) * SECP256k1.generator
            commitments.append(commitment)
        return shares, commitments

class Participant:
    """参与方节点"""
    def __init__(self, sk_share: int, pk_commitments: List[ellipticcurve.PointJacobi]):
        self.sk_share = sk_share
        self.pk_commitments = pk_commitments  # Feldman承诺
        
    def compute_partial_sig(self, k_share: int, msg_hash: int, R: int) -> int:
        h = msg_hash
        r = R % SECP256k1.order
        s_i = (k_share * h + r * self.sk_share) % SECP256k1.order
        return s_i
  
class ThresholdECDSA:
    def __init__(self, t: int, n: int):
        self.t = t
        self.n = n
        self.vss = FeldmanVSS(t, n)
        self.paillier_pubkey, self.paillier_privkey = paillier.generate_paillier_keypair()
        self.k_pool = []  # 随机数k的分片池
        
    def keygen_phase(self) -> Tuple[List[Participant], VerifyingKey]:
        secret = random.randint(1, SECP256k1.order)
        sk_shares, commitments = self.vss.generate_shares(secret)
        participants = [Participant(sk_share, commitments) for sk_share in sk_shares]
        pubkey_point = secret * SECP256k1.generator
        pubkey = VerifyingKey.from_public_point(pubkey_point, curve=SECP256k1)
        return participants, pubkey
    
    def precompute_phase(self, participants: List[Participant], num_precomputed: int = 10):
        for _ in range(num_precomputed):
            k = random.randint(1, SECP256k1.order)
            k_shares, _ = self.vss.generate_shares(k)
            encrypted_shares = [self.paillier_pubkey.encrypt(share) for share in k_shares]
            self.k_pool.append({
                'shares': k_shares,
                'encrypted': encrypted_shares,
                'R': k * SECP256k1.generator
            })
    
    def signing_phase(self, participants: List[Participant], msg: bytes) -> Tuple[int, int]:
        msg_hash = int.from_bytes(hashlib.sha256(msg).digest(), 'big')
        selected_k = msg_hash % len(self.k_pool)
        k_data = self.k_pool[selected_k]
        R = k_data['R'].x()  # r = R.x mod n
        
        partial_sigs = []
        for i, participant in enumerate(participants[:self.t]):  # 选取t个参与方
            k_share = self.paillier_privkey.decrypt(k_data['encrypted'][i])
            s_i = participant.compute_partial_sig(k_share, msg_hash, R)
            partial_sigs.append(s_i)
        
        s = sum(partial_sigs) % SECP256k1.order
        return (R, s)
    
    @staticmethod
    def verify_sig(pubkey: VerifyingKey, msg: bytes, sig: Tuple[int, int]) -> bool:
        try:
            der_sig = sigencode_der(sig[0], sig[1], SECP256k1.order)
            pubkey.verify(der_sig, msg, hashfunc=hashlib.sha256, sigdecode=sigdecode_der)
            return True
        except Exception as e:
            print(f"Verification failed with exception: {e}")
            return False

if __name__ == "__main__":
    t = 3
    n = 5
    msg = b"Hello, Threshold ECDSA!"
    
    threshold_ecdsa = ThresholdECDSA(t, n)
    
    participants, pubkey = threshold_ecdsa.keygen_phase()
    print(f"Generated Public Key (compressed): {pubkey.to_string('compressed').hex()}")
    
    threshold_ecdsa.precompute_phase(participants, num_precomputed=10)
    
    r, s = threshold_ecdsa.signing_phase(participants, msg)
    print(f"Threshold Signature (r, s): {hex(r)}, {hex(s)}")
    
    is_valid = threshold_ecdsa.verify_sig(pubkey, msg, (r, s))
    print(f"Signature Valid: {is_valid}")