import hashlib
from typing import List, Tuple
from ecdsa import SECP256k1, VerifyingKey, ellipticcurve, numbertheory
from ecdsa.ellipticcurve import PointJacobi
from phe import paillier
import random

def lagrange_coeff(i: int, participants: List[int], prime: int) -> int:
    numerator = 1
    denominator = 1
    for j in participants:
        if i != j:
            numerator = (numerator * (0 - j)) % prime
            denominator = (denominator * (i - j)) % prime
    return (numerator * numbertheory.inverse_mod(denominator, prime)) % prime

def schnorr_prove(secret: int, generator: PointJacobi, public: PointJacobi) -> Tuple[int, int]:
    v = random.randint(1, SECP256k1.order)
    V = v * generator
    c = int.from_bytes(hashlib.sha256(
        generator.to_bytes(encoding='compressed') + 
        V.to_bytes(encoding='compressed') + 
        public.to_bytes(encoding='compressed')
    ).digest(), 'big') % SECP256k1.order
    r = (v - c * secret) % SECP256k1.order
    return (c, r)

def schnorr_verify(public: PointJacobi, generator: PointJacobi, proof: Tuple[int, int]) -> bool:
    c, r = proof
    V_prime = r * generator + c * public
    c_prime = int.from_bytes(hashlib.sha256(
        generator.to_bytes(encoding='compressed') + 
        V_prime.to_bytes(encoding='compressed') + 
        public.to_bytes(encoding='compressed')
    ).digest(), 'big') % SECP256k1.order
    return c == c_prime

class FeldmanVSS:
    def __init__(self, t: int, n: int):
        self.t = t
        self.n = n
    
    def generate_shares(self, secret: int) -> Tuple[List[Tuple[int, int]], List[PointJacobi]]:
        coeffs = [secret] + [random.randint(0, SECP256k1.order) for _ in range(self.t-1)]
        shares = []
        public_shares = []
        for i in range(1, self.n+1):
            share = sum(coeff * pow(i, j, SECP256k1.order) for j, coeff in enumerate(coeffs)) % SECP256k1.order
            shares.append((i, share))
            public_shares.append(share * SECP256k1.generator)
        return shares, public_shares

class ThresholdECDSA:
    def __init__(self, t: int, n: int):
        self.t = t
        self.n = n
        self.vss = FeldmanVSS(t, n)
        self.paillier_pubkey, self.paillier_privkey = paillier.generate_paillier_keypair()
    
    def keygen_phase(self) -> Tuple[List[Tuple[int, int]], VerifyingKey]:
        secret = random.randint(1, SECP256k1.order)
        sk_shares, _ = self.vss.generate_shares(secret)
        pubkey_point = secret * SECP256k1.generator
        pubkey = VerifyingKey.from_public_point(pubkey_point, curve=SECP256k1)
        return sk_shares, pubkey
    
    def precompute_phase(self, participants: List[Tuple[int, int]], num_precomputed: int = 10) -> List[dict]:
        k_pool = []
        for _ in range(num_precomputed):
            k = random.randint(1, SECP256k1.order)
            k_shares, _ = self.vss.generate_shares(k)
            encrypted_shares = [self.paillier_pubkey.encrypt(share[1]) for share in k_shares]
            R = k * SECP256k1.generator
            k_pool.append({'shares': k_shares, 'encrypted': encrypted_shares, 'R': R})
        return k_pool
    
    def signing_phase(self, sk_shares: List[Tuple[int, int]], k_pool: List[dict], msg: bytes) -> Tuple[int, int]:
        h = int.from_bytes(hashlib.sha256(msg).digest(), 'big')
        selected_k = h % len(k_pool)
        k_data = k_pool[selected_k]
        R = k_data['R'].x()
        r = R % SECP256k1.order
        participants = [share[0] for share in sk_shares[:self.t]]

        # 生成 gamma 分片及公开承诺
        gamma_shares, gamma_public_shares = self.vss.generate_shares(random.randint(1, SECP256k1.order))
        
        # 验证 gamma 分片
        for (i, gamma_i), public_share in zip(gamma_shares[:self.t], gamma_public_shares[:self.t]):
            proof = schnorr_prove(gamma_i, SECP256k1.generator, public_share)
            if not schnorr_verify(public_share, SECP256k1.generator, proof):
                raise ValueError(f"Invalid gamma share from participant {i}")

        # 计算 k^{-1}
        k = sum(share[1] * lagrange_coeff(share[0], participants, SECP256k1.order) 
               for share in k_data['shares'][:self.t]) % SECP256k1.order
        gamma = sum(share[1] * lagrange_coeff(share[0], participants, SECP256k1.order) 
                   for share in gamma_shares[:self.t]) % SECP256k1.order
        Gamma = (k * gamma) % SECP256k1.order
        Gamma_inv = pow(Gamma, -1, SECP256k1.order)
        k_inv_shares = [(s[0], (s[1] * Gamma_inv) % SECP256k1.order) for s in gamma_shares[:self.t]]
        k_inv = sum(s[1] * lagrange_coeff(s[0], participants, SECP256k1.order) for s in k_inv_shares) % SECP256k1.order

        # 计算签名 s
        s = sum(
            (lagrange_coeff(i, participants, SECP256k1.order) * (h + r * d_i) * k_inv) % SECP256k1.order
            for (i, d_i) in sk_shares[:self.t]
        ) % SECP256k1.order
        return (r, s)
    
    @staticmethod
    def verify_sig(pubkey: VerifyingKey, msg: bytes, sig: Tuple[int, int]) -> bool:
        try:
            sig_bytes = sig[0].to_bytes(32, 'big') + sig[1].to_bytes(32, 'big')
            pubkey.verify_digest(
                sig_bytes,
                digest=hashlib.sha256(msg).digest(),
                sigdecode=lambda sig_bytes, order: (
                    int.from_bytes(sig_bytes[:32], 'big'),
                    int.from_bytes(sig_bytes[32:], 'big')
                )
            )
            return True
        except Exception as e:
            print(f"Verification failed: {e}")
            return False

if __name__ == "__main__":
    t = 3
    n = 5
    msg = b"Hello, Threshold ECDSA!"
    threshold_ecdsa = ThresholdECDSA(t, n)
    sk_shares, pubkey = threshold_ecdsa.keygen_phase()
    k_pool = threshold_ecdsa.precompute_phase(sk_shares)
    r, s = threshold_ecdsa.signing_phase(sk_shares, k_pool, msg)
    print(f"Signature Valid: {threshold_ecdsa.verify_sig(pubkey, msg, (r, s))}")