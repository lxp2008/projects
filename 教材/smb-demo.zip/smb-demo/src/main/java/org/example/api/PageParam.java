package org.example.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

/**
 * <p>
 *
 * </p>
 *
 * @author kirk
 * @since 2020/12/22
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class PageParam {
    protected Integer pageSize=5;

    protected Integer current=1;
}
