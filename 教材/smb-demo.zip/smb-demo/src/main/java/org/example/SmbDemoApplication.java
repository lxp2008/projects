package org.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * <p>
 *
 * </p>
 *
 * @author kirk
 * @since 2023/9/19
 */
@SpringBootApplication
public class SmbDemoApplication {
    public static void main(String[] args) {
        SpringApplication.run(SmbDemoApplication.class, args);
    }
}