package org.example.util;

import jcifs.smb.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.FileCopyUtils;

import java.io.*;
import java.net.MalformedURLException;
import java.net.UnknownHostException;
import java.util.Objects;
/**
 * @author: Create By 成猿手册
 * @description: Java中SMB的上传和下载
 * @date: 2020/03/22
 */

/**
 * <p>
 *
 * </p>
 *
 * @author kirk
 * @since 2021/7/22
 */
public class SmbUtils {
    public static final Logger log = LoggerFactory.getLogger(SmbUtils.class);

    private static String ip;

    private static String username;

    private static String password;

    private static NtlmPasswordAuthentication auth;

    /**
     * 登录认证
     *
     * @return
     */
    public static NtlmPasswordAuthentication auth(String smbUrl) {
        if (!smbUrl.startsWith("smb://")) {
            throw new RuntimeException("SMB地址错误");
        }
        smbUrl = smbUrl.substring("smb://".length());
        // 将smburl截取为 smb://admin:admin@192.168.1.106
        smbUrl = smbUrl.substring(0, smbUrl.indexOf("/"));
        username = smbUrl.substring(0, smbUrl.lastIndexOf(":"));
        password = smbUrl.substring(smbUrl.lastIndexOf(":") + 1, smbUrl.lastIndexOf("@"));
        ip = smbUrl.substring(smbUrl.lastIndexOf("@") + 1);
        if (StringUtils.isBlank(ip) || StringUtils.isBlank(username) || StringUtils.isBlank(password)) {
            throw new RuntimeException("SMB地址错误");
        }
        auth = new NtlmPasswordAuthentication(ip, username, password);
        return auth;
    }

    /**
     * 创建 SmbFile
     *
     * @param path
     * @return
     */
    public static SmbFile createSmbFile(String path) {
        if (Objects.isNull(auth)) {
            throw new RuntimeException("no auth");
        }
        //smb请求的url
        String smburl = String.format("smb://%s/%s", ip, path);
        try {
            return new SmbFile(smburl, auth);
        } catch (MalformedURLException e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    /**
     * 检测SMB共享文件夹中的文件是否存在
     *
     * @param path
     * @return
     */
    public static boolean checkSmbFile(String path) {
        if (Objects.isNull(auth)) {
            throw new RuntimeException("no auth");
        }
        boolean result = false;
        try {
            //smb请求的url
            String smburl = String.format("smb://%s/%s", ip, path);
            SmbFile smbFile = new SmbFile(smburl, auth);
            result = smbFile.exists();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return result;
    }

    /**
     * 上传
     *
     * @param sourcePath
     * @param targetPath
     * @return
     * @throws MalformedURLException
     */
    public static boolean uploadSmbFile(String sourcePath, String targetPath) {
        if (Objects.isNull(auth)) {
            throw new RuntimeException("no auth");
        }
        InputStream in = null;
        OutputStream out = null;
        try {
            String smburl = String.format("smb://%s/%s", ip, targetPath);
            SmbFile smbFile = new SmbFile(smburl, auth);
            in = new BufferedInputStream(new FileInputStream(sourcePath));
            out = new BufferedOutputStream(new SmbFileOutputStream(smbFile));
            FileCopyUtils.copy(in, out);
            return true;
        } catch (SmbException e) {
            log.error(e.getMessage(), e);
        } catch (UnknownHostException e) {
            log.error(e.getMessage(), e);
        } catch (FileNotFoundException e) {
            log.error(e.getMessage(), e);
        } catch (IOException e) {
            log.error(e.getMessage(), e);
        } finally {
            closeStreanm(in, out);
        }
        return false;
    }

    public static boolean uploadSmbFileBySmbUrlNoAuth(String sourcePath, String smburl) {
        InputStream in = null;
        OutputStream out = null;
        try {
            SmbFile smbFile = new SmbFile(smburl);
            in = new BufferedInputStream(new FileInputStream(sourcePath));
            out = new BufferedOutputStream(new SmbFileOutputStream(smbFile));
            FileCopyUtils.copy(in, out);
            return true;
        } catch (SmbException e) {
            log.error(e.getMessage(), e);
        } catch (UnknownHostException e) {
            log.error(e.getMessage(), e);
        } catch (FileNotFoundException e) {
            log.error(e.getMessage(), e);
        } catch (IOException e) {
            log.error(e.getMessage(), e);
        } finally {
            closeStreanm(in, out);
        }
        return false;
    }

    public static boolean uploadSmbFileBySmbUrlWithAuth(String sourcePath, String smburl) {
        auth(smburl);
        if (Objects.isNull(auth)) {
            throw new RuntimeException("no auth");
        }
        InputStream in = null;
        OutputStream out = null;
        try {
            SmbFile smbFile = new SmbFile(smburl, auth);
            in = new BufferedInputStream(new FileInputStream(sourcePath));
            out = new BufferedOutputStream(new SmbFileOutputStream(smbFile));
            FileCopyUtils.copy(in, out);
            return true;
        } catch (SmbException e) {
            log.error(e.getMessage(), e);
        } catch (UnknownHostException e) {
            log.error(e.getMessage(), e);
        } catch (FileNotFoundException e) {
            log.error(e.getMessage(), e);
        } catch (IOException e) {
            log.error(e.getMessage(), e);
        } finally {
            closeStreanm(in, out);
        }
        return false;
    }


    /**
     * 下载文件
     *
     * @param sourcePath
     * @param targetPath
     * @return
     * @throws MalformedURLException
     */
    public static boolean downloadSmbFile(String sourcePath, String targetPath) {
        InputStream in = null;
        OutputStream out = null;
        try {
            String smburl = String.format("smb://%s/%s", ip, sourcePath);
            SmbFile smbFile = new SmbFile(smburl, auth);
            in = new BufferedInputStream(new SmbFileInputStream(smbFile));
            out = new BufferedOutputStream(new FileOutputStream(targetPath));
            FileCopyUtils.copy(in, out);
            return true;
        } catch (SmbException e) {
            log.error(e.getMessage(), e);
        } catch (UnknownHostException e) {
            log.error(e.getMessage(), e);
        } catch (FileNotFoundException e) {
            log.error(e.getMessage(), e);
        } catch (IOException e) {
            log.error(e.getMessage(), e);
        } finally {
            closeStreanm(in, out);
        }
        return false;
    }

    /**
     * 关闭文件流
     *
     * @param in
     * @param out
     */
    private static void closeStreanm(InputStream in, OutputStream out) {
        try {
            if (in != null) {
                in.close();
            }
            if (out != null) {
                out.close();
            }
        } catch (IOException e) {
            log.error(e.getMessage(), e);
        }
    }

    public static void main(String[] args) {
        SmbUtils.auth("smb://yougong:123@192.168.50.201/");
        boolean b1 = SmbUtils.downloadSmbFile("/smb/test.txt", "D:/test.txt");
        boolean b2 = SmbUtils.uploadSmbFile("D:/test.txt", "/smb/test.txt");
        System.out.println(b1);
        System.out.println(b2);
    }
}