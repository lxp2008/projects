package org.example.controller;

import cn.hutool.core.io.FileUtil;
import cn.hutool.core.lang.UUID;
import org.example.api.CommonResult;
import org.example.util.SmbUtils;
import org.springframework.web.bind.annotation.*;

import java.io.File;

/**
 * <p>
 *
 * </p>
 *
 * @author kirk
 * @since 2023/9/19
 */
@RequestMapping("/test")
@RestController
public class TestController {

    @GetMapping("apiKey")
    public CommonResult apiKey() {
        return CommonResult.success(UUID.randomUUID().toString(true));
    }

    @GetMapping("/api")
    public CommonResult getJson(@RequestParam("apiKey") String apiKey) {
        // 检查 apiKey 是否有效，如果无效，返回错误信息
        if (!isValidApiKey(apiKey)) {
            return CommonResult.failed("Invalid API key");
        }

        // 构建 JSON 内容（这里示例使用一个简单的 JSON）
        String json = "{\"name\": \"John\", \"age\": 30}";

        // 调用 jcifs 将 JSON 写入 Windows 共享盘
        writeJsonToSharedDrive(json);

        return CommonResult.success(json);
    }

    private boolean isValidApiKey(String apiKey) {
        // 在实际应用中，你需要验证 apiKey 的有效性
        // 这里简化为检查 apiKey 是否为空
        return apiKey != null && !apiKey.isEmpty();
    }

    private void writeJsonToSharedDrive(String json) {
        String jsonName = UUID.randomUUID().toString(true) + ".json";
        String smbPath = "smb://yougong:123@192.168.50.201/smb/";
        String path = smbPath + jsonName;
        File jsonFile = FileUtil.writeBytes(json.getBytes(), "D:/test/" + jsonName);
        // 使用 jcifs 将 JSON 写入 Windows 共享盘的逻辑
        // sourcePath : jsonFile.getAbsolutePath()
        // targetPath : path
        SmbUtils.uploadSmbFileBySmbUrlWithAuth(jsonFile.getAbsolutePath(), path);
    }

}
